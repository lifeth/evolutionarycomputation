/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package unalcol.learn.unsupervised.partition;


/**
 *
 * @author jgomez
 */
public class CentroidRecognizerInstanceService<T> {
//    implements InstanceService<CentroidsRecognizer<T>> {

//    @Override
//    public CentroidsRecognizer<T> get( CentroidsRecognizer<T> r ) {
//        return new CentroidsRecognizer(null, r.metric(), r.aggregator());
//    }

//    @Override
//    public Object owner() {
//        return CentroidsRecognizer.class;
//    }
    
}
