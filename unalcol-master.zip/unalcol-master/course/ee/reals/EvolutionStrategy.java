package ee.reals;

public class EvolutionStrategy {

}
